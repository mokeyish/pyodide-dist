from joblib.test import test_memory
from joblib.test import test_hashing
