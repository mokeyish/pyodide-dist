"""
test package backported for python-future.

Its primary purpose is to allow use of "import test.support" for running
the Python standard library unit tests using the new Python 3 stdlib
import location.

Python 3 renamed test.test_support to test.support.
"""
